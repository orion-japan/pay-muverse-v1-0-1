export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { verifyFirebaseAndAuthorize, SUPABASE_URL, SERVICE_ROLE } from '@/lib/authz';
import { createClient } from '@supabase/supabase-js';
import { generateIrosReply } from '../../../../../lib/iros/generate';  // ← 既存の返信生成ロジックに合わせて

const supabase = createClient(SUPABASE_URL!, SERVICE_ROLE!);

/**
 * POST /api/agent/iros/messages
 * { convId, userText }
 * 1) user 発言を保存
 * 2) 返信生成
 * 3) assistant 発言を保存して返す
 */
export async function POST(req: NextRequest) {
  const { uid } = await verifyFirebaseAndAuthorize(req);
  const { convId, userText } = await req.json();

  if (!convId) return NextResponse.json({ error: 'convId is required' }, { status: 400 });
  if (!userText || !String(userText).trim())
    return NextResponse.json({ error: 'text_empty' }, { status: 400 });

  // 会話が本人のものか軽く確認
  const { data: conv, error: convErr } = await supabase
    .from('iros_conversations')
    .select('id')
    .eq('id', convId)
    .eq('user_code', uid)
    .single();
  if (convErr || !conv) return NextResponse.json({ error: 'conversation_not_found' }, { status: 404 });

  // 直近メッセージを取って文脈を組み立て（必要に応じて件数絞り）
  const { data: history } = await supabase
    .from('iros_messages')
    .select('role,content')
    .eq('conv_id', convId)
    .order('ts', { ascending: true })
    .limit(40);

  // 1) ユーザー発言保存
  await supabase.from('iros_messages').insert({
    conv_id: convId,
    user_code: uid,
    role: 'user',
    content: userText,
  });

  // 2) 返信生成
  const reply = await generateIrosReply({
    userText,
    history: history ?? [],
    meta: { agent: 'iros' },
  });

  // 3) assistant 発言保存
  const { data: saved } = await supabase
    .from('iros_messages')
    .insert({
      conv_id: convId,
      user_code: uid,
      role: 'assistant',
      content: reply ?? '',
    })
    .select('id,content,ts')
    .single();

  // 会話の updated_at を触る
  await supabase
    .from('iros_conversations')
    .update({ updated_at: new Date().toISOString() })
    .eq('id', convId);

  return NextResponse.json({
    message: { id: saved?.id, role: 'assistant', text: saved?.content, ts: saved?.ts },
  });
}
