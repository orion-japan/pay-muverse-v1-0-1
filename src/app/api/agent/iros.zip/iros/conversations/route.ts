export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { verifyFirebaseAndAuthorize, SUPABASE_URL, SERVICE_ROLE } from '@/lib/authz';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(SUPABASE_URL!, SERVICE_ROLE!);

/**
 * GET  /api/agent/iros/conversations?limit=50
 * POST /api/agent/iros/conversations   { title? }
 */
export async function GET(req: NextRequest) {
  const { uid } = await verifyFirebaseAndAuthorize(req);
  const url = new URL(req.url);
  const limit = Number(url.searchParams.get('limit') ?? 50);

  const { data, error } = await supabase
    .from('iros_conversations')
    .select('id,title,updated_at')
    .eq('user_code', uid)
    .order('updated_at', { ascending: false })
    .limit(limit);

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ conversations: data ?? [] });
}

export async function POST(req: NextRequest) {
  const { uid } = await verifyFirebaseAndAuthorize(req);
  const body = await req.json().catch(() => ({}));
  const title = (body?.title ?? '新規セッション').slice(0, 120);

  const { data, error } = await supabase
    .from('iros_conversations')
    .insert({ user_code: uid, title })
    .select('id,title,updated_at')
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ conversation: data });
}
