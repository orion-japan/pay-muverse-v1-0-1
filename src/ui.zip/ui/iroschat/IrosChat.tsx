'use client';

import { IrosChatProvider } from './IrosChatContext';
import IrosChatShell from './IrosChatShell';

export default function IrosChat({ open }: { open?: string }) {
  return (
    <IrosChatProvider>
      <IrosChatShell open={open} />
    </IrosChatProvider>
  );
}
