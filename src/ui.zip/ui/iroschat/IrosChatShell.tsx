'use client';

import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import { SOFIA_CONFIG } from '@/lib/sofia/config';

import IrosSidebarMobile from './IrosSidebarMobile';
import IrosHeader from './IrosHeader';
import MessageList from './components/MessageList';
import ChatInput from './components/ChatInput';

import './IrosChat.css';
import { IrosChatProvider, useIrosChat } from './IrosChatContext';

type CurrentUser = {
  id: string;
  name: string;
  userType: string;
  credits: number;
  avatarUrl?: string | null;
};
type Props = { open?: string };

type OpenTarget =
  | { type: null; cid?: undefined }
  | { type: 'menu'; cid?: undefined }
  | { type: 'new'; cid?: undefined }
  | { type: 'cid'; cid: string }
  | { type: 'uuid'; cid: string };

const lastConvKey = (agent: string) => `sofia:lastConv:${agent}`;

function IrosChatInner({ open }: Props) {
  const sp = useSearchParams();
  const urlCid = sp?.get('cid') ?? undefined;

  const agentK = 'iros';
  const { loading: authLoading, userCode } = useAuth();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [uiUser, setUiUser] = useState<CurrentUser>();
  const [meta, setMeta] = useState<any>(null);

  const composeRef = useRef<HTMLDivElement | null>(null);
  const canUse = useMemo(() => !!userCode && !authLoading, [userCode, authLoading]);

  const openTarget: OpenTarget = useMemo(() => {
    if (!open) return { type: null, cid: undefined };
    if (open === 'menu') return { type: 'menu', cid: undefined };
    if (open === 'new') return { type: 'new', cid: undefined };
    if (open.startsWith('cid:')) return { type: 'cid', cid: open.slice(4) };
    return { type: 'uuid', cid: open };
  }, [open]);

  // テーマ設定
  useEffect(() => {
    const ui = ((SOFIA_CONFIG as any)?.ui ?? {}) as Record<string, any>;
    const get = <T,>(v: T | undefined, d: T) => v ?? d;
    const set = (k: string, v: string) => document.documentElement.style.setProperty(k, v);
    set('--sofia-container-maxw', `${get(ui.containerMaxWidth, 840)}px`);
    set('--sofia-bubble-maxw', `${get(ui.bubbleMaxWidthPct, 88)}%`);
    set('--sofia-a-border', get(ui.assistantBorder, '1px solid rgba(255,255,255,0.08)'));
    set('--sofia-a-radius', `${get(ui.assistantRadius, 14)}px`);
    set('--sofia-a-shadow', get(ui.assistantShadow, '0 4px 24px rgba(0,0,0,0.25)'));
    set('--sofia-a-bg', get(ui.assistantBg, 'rgba(255,255,255,0.04)'));
    set('--sofia-bq-border', get(ui.blockquoteTintBorder, '1px solid rgba(160,200,255,0.25)'));
    set('--sofia-bq-bg', get(ui.blockquoteTintBg, 'rgba(160,200,255,0.06)'));
    set('--sofia-user-bg', get(ui.userBg, 'rgba(0,0,0,0.25)'));
    set('--sofia-user-fg', get(ui.userFg, '#fff'));
    set('--sofia-user-border', get(ui.userBorder, '1px solid rgba(255,255,255,0.08)'));
    set('--sofia-user-radius', `${get(ui.userRadius, 14)}px`);
  }, []);

  // Compose 高さ調整
  useLayoutEffect(() => {
    const el = composeRef.current;
    if (!el) return;
    const set = () =>
      document.documentElement.style.setProperty('--sof-compose-h', `${el.offsetHeight}px`);
    set();
    const ro = new ResizeObserver(set);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // ==== Iros Context ====
  const chat = useIrosChat();

  // 初期選択（一覧取得は Context に任せる）。StrictModeで一度だけ。
  const didSelectOnce = useRef(false);
  useEffect(() => {
    if (!canUse) return;
    if (didSelectOnce.current) return;
    if (!chat.conversations.length) return;

    const sorted = [...chat.conversations].sort((a, b) => {
      const ta = new Date(a.updated_at || 0).getTime();
      const tb = new Date(b.updated_at || 0).getTime();
      return tb - ta;
    });

    const stored =
      typeof window !== 'undefined'
        ? window.localStorage.getItem(lastConvKey(agentK)) || undefined
        : undefined;

    const prefer =
      (openTarget.type === 'cid' &&
        openTarget.cid &&
        sorted.find((i) => i.id === openTarget.cid)?.id) ||
      (urlCid && sorted.find((i) => i.id === urlCid)?.id) ||
      (stored && sorted.find((i) => i.id === stored)?.id) ||
      sorted[0]?.id;

    if (prefer) {
      didSelectOnce.current = true;
      chat.selectConversation(prefer);
      try {
        window.localStorage.setItem(lastConvKey(agentK), prefer);
      } catch {}
    }
  }, [canUse, chat.conversations, chat, openTarget, urlCid]);

  // ユーザー情報
  useEffect(() => {
    if (!userCode) return;
    setUiUser({ id: userCode, name: 'You', userType: 'member', credits: 0 });
  }, [userCode]);

  const handleDelete = async () => {
    if (chat.conversationId) await chat.remove();
  };
  const handleRename = async () => {};

  return (
    <div className="sofia-container sof-center">
      <div className="sof-header-fixed">
        <IrosHeader
          onShowSideBar={() => setIsMobileMenuOpen(true)}
          onCreateNewChat={() => {
            try {
              window.localStorage.removeItem(lastConvKey(agentK));
            } catch {}
          }}
        />
      </div>

      <div
        className="sof-top-spacer"
        style={{ height: 'calc(var(--sof-header-h, 56px) + 12px)' }}
        aria-hidden
      />

      {authLoading ? (
        <div style={{ display: 'grid', placeItems: 'center', minHeight: '60vh' }}>読み込み中…</div>
      ) : !userCode ? (
        <div style={{ display: 'grid', placeItems: 'center', minHeight: '60vh' }}>
          ログインが必要です
        </div>
      ) : (
        <>
          <IrosSidebarMobile
            isOpen={isMobileMenuOpen}
            onClose={() => setIsMobileMenuOpen(false)}
            conversations={chat.conversations}
            onSelect={(id) => {
              chat.selectConversation(id);
              setIsMobileMenuOpen(false);
              try {
                window.localStorage.setItem(lastConvKey(agentK), id);
              } catch {}
            }}
            onDelete={handleDelete}
            onRename={handleRename}
            userInfo={uiUser ?? null}
            meta={meta as any}
          />

          <MessageList />

          <div className="sof-compose-dock" ref={composeRef}>
            <ChatInput />
          </div>
        </>
      )}

      <div className="sof-underlay" aria-hidden />
      <div className="sof-footer-spacer" />
    </div>
  );
}

export default function IrosChatShell(props: Props) {
  return (
    <IrosChatProvider>
      <IrosChatInner {...props} />
    </IrosChatProvider>
  );
}
