'use client';

import React from 'react';
import { useIrosChat } from '../IrosChatContext';
import styles from '../index.module.css';

type IrosMessage = {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  q?: 'Q1' | 'Q2' | 'Q3' | 'Q4' | 'Q5';
  color?: string;
  ts?: number;
};

export default function MessageList() {
  const ctx = (useIrosChat() as {
    messages: any[]; // ← 受けは any[] に広げておく（content/created_at 型も受容）
    loading: boolean;
    error?: string | null;
  }) ?? { messages: [], loading: false, error: null };

  const { loading, error } = ctx;

  // ここで UI 既存型(IrosMessage)へ正規化
  const messages: IrosMessage[] = React.useMemo(() => {
    const arr = Array.isArray(ctx.messages) ? ctx.messages : [];
    return arr
      .map((m) => {
        const id = String(m.id ?? cryptoRandom());
        const role: 'user' | 'assistant' = m.role === 'assistant' ? 'assistant' : 'user';
        const text: string = String(
          m.text ?? m.content ?? '', // ← content を text に吸収
        );
        // ts 優先 / created_at 補完
        const ts: number | undefined =
          typeof m.ts === 'number'
            ? m.ts
            : m.created_at
              ? new Date(m.created_at).getTime()
              : m.createdAt
                ? new Date(m.createdAt).getTime()
                : undefined;

        const q = (m.q as IrosMessage['q']) ?? undefined;
        const color = (m.color as string) ?? undefined;

        return { id, role, text, q, color, ts };
      })
      .sort((a, b) => (a.ts ?? 0) - (b.ts ?? 0));
  }, [ctx.messages]);

  // ===== 自動スクロール（Sofia準拠） =====
  const listRef = React.useRef<HTMLDivElement | null>(null);
  const bottomRef = React.useRef<HTMLDivElement | null>(null);
  const first = React.useRef(true);

  const scrollToBottom = (behavior: ScrollBehavior = 'auto') => {
    const el = bottomRef.current;
    if (!el) return;
    if (typeof window !== 'undefined') {
      window.requestAnimationFrame(() => {
        el.scrollIntoView({ behavior, block: 'end' });
      });
    }
  };

  React.useEffect(() => {
    scrollToBottom(first.current ? 'auto' : 'smooth');
    first.current = false;
  }, [messages]);

  React.useEffect(() => {
    const onUp = () => {
      // 型を広げて安全に扱う（scrollingElement は Element|null）
      const el: Element | null =
        listRef.current ||
        (typeof document !== 'undefined'
          ? document.querySelector('.sof-msgs') ||
            document.querySelector('[data-sof-chat-scroll]') ||
            document.scrollingElement
          : null);

      // 最終フォールバック
      const box: Element | null =
        el ?? (typeof document !== 'undefined' ? document.documentElement : null);
      if (!box) return;

      const top = Math.max(0, (box as any).scrollTop - 200);
      if (typeof (box as any).scrollTo === 'function') {
        (box as any).scrollTo({ top, behavior: 'smooth' });
      } else {
        (box as any).scrollTop = top;
      }
    };

    if (typeof window !== 'undefined') {
      window.addEventListener('sof:scrollUp', onUp);
      return () => window.removeEventListener('sof:scrollUp', onUp);
    }
    return () => {};
  }, []);

  return (
    <div ref={listRef} className={styles.timeline} role="log" aria-live="polite">
      {!messages.length && !loading && !error && (
        <div className={styles.emptyHint}>ここに会話が表示されます</div>
      )}

      {messages.map((m) => {
        const isUser = m.role === 'user';
        return (
          <div
            key={m.id || `${m.role}-${m.ts ?? Math.random()}`}
            className={isUser ? styles.msgUser : styles.msgBot}
            style={{
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'flex-start',
              gap: 10,
              justifyContent: isUser ? 'flex-end' : 'flex-start',
            }}
          >
            {!isUser && (
              <img
                src="/ir.png"
                alt="Iros"
                width={32}
                height={32}
                style={{ width: 32, height: 32, borderRadius: '50%', objectFit: 'cover' }}
              />
            )}

            <div style={{ maxWidth: 'min(92%, 680px)' }}>
              {m.q && (
                <div
                  className={styles.msgBadge}
                  style={{
                    display: 'inline-block',
                    padding: '2px 8px',
                    borderRadius: 999,
                    fontSize: 12,
                    marginBottom: 6,
                    backgroundColor: '#fff',
                    border: '1px solid rgba(15,23,42,.08)',
                    color: '#334155',
                  }}
                >
                  <span
                    style={{
                      display: 'inline-block',
                      width: 10,
                      height: 10,
                      borderRadius: 999,
                      background: m.color || '#94a3b8',
                      marginRight: 6,
                      verticalAlign: 'middle',
                    }}
                  />
                  {m.q}
                </div>
              )}

              <div
                className={styles.msgBubble}
                style={
                  isUser
                    ? {
                        background: 'linear-gradient(180deg,#ffffff 0%,#eef5ff 100%)',
                        border: '1px solid #cfe0ff',
                        color: '#0b1220',
                        boxShadow: '0 1px 3px rgba(16,24,40,.06), 0 8px 24px rgba(30,64,175,.06)',
                        borderRadius: 16,
                      }
                    : {
                        background: 'linear-gradient(180deg,#ffffff 0%,#f7f9fc 100%)',
                        border: '1px solid #e6eaf2',
                        color: '#0f172a',
                        boxShadow: '0 1px 3px rgba(16,24,40,.06), 0 8px 24px rgba(2,6,23,.05)',
                        borderRadius: 16,
                      }
                }
              >
                <p
                  className={styles.msgText}
                  style={{
                    lineHeight: 1.85,
                    letterSpacing: '0.01em',
                    whiteSpace: 'pre-wrap',
                    margin: 0,
                  }}
                >
                  {m.text}
                </p>
              </div>
            </div>

            {isUser && (
              <img
                src="/me.png"
                onError={(e) => {
                  e.currentTarget.onerror = null;
                  e.currentTarget.src = '/mu_ai.png';
                }}
                alt="you"
                width={32}
                height={32}
                style={{ width: 32, height: 32, borderRadius: '50%', objectFit: 'cover' }}
              />
            )}
          </div>
        );
      })}

      {loading && (
        <div className={styles.loadingRow}>
          <div className={styles.dotAnim} />
          <div className={styles.dotAnim} />
          <div className={styles.dotAnim} />
        </div>
      )}
      {error && <div className={styles.error}>{error}</div>}

      <div ref={bottomRef} />
    </div>
  );
}

function cryptoRandom(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    // @ts-ignore
    return crypto.randomUUID();
  }
  return 'tmp_' + Math.random().toString(36).slice(2);
}
