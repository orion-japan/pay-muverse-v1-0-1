'use client';

import React, { useState } from 'react';
import Sidebar from './IrosSidebarMobile';
import IrosChat from './IrosChat';

export default function IrosLayout() {
  const [open, setOpen] = useState(false);

  // --- 型をまず通すための最小ダミー値（後で実装に置き換え） ---
  const conversations = [] as any[]; // TODO: API 連携で会話一覧を入れる
  const userInfo = null as any; // TODO: ユーザー情報を入れる
  const noop = () => {}; // TODO: 各ハンドラ実装

  return (
    <div className="iros-layout">
      {/* <button onClick={() => setOpen(true)}>Open Sidebar</button> */}

      <Sidebar
        isOpen={open}
        onClose={() => setOpen(false)}
        conversations={conversations}
        onSelect={noop}
        onDelete={noop}
        onRename={noop}
        userInfo={userInfo}
      />

      <IrosChat />
    </div>
  );
}
