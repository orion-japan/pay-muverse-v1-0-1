// src/ui/iroschat/lib/irosClient.ts
import { getAuth } from 'firebase/auth';
import type { IrosConversation, IrosMessage } from '../types';

/** API応答を一旦ここに正規化してから IrosMessage へキャストする */
type WireMsg = {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  q?: any;
  color?: string;
  ts?: number;
};

type SendIn = {
  conversationId?: string;
  text: string;
  mode?: string;
};

// ---------------- helpers ----------------
function arr<T = any>(data: any): T[] {
  if (Array.isArray(data?.messages)) return data.messages;
  if (Array.isArray(data?.rows)) return data.rows;
  if (Array.isArray(data?.items)) return data.items;
  if (Array.isArray(data)) return data;
  return [];
}
function num(v: any): number | undefined {
  if (typeof v === 'number' && Number.isFinite(v)) return v;
  if (typeof v === 'string' && v) {
    const t = Date.parse(v);
    if (!Number.isNaN(t)) return t;
  }
  return undefined;
}
async function getIdTokenSafe(force = false): Promise<string | null> {
  try {
    const u = getAuth().currentUser;
    if (!u) return null;
    return await u.getIdToken(force);
  } catch {
    return null;
  }
}
function hasSessionCookie(): boolean {
  try {
    if (typeof document === 'undefined') return false;
    return document.cookie.split(';').some((c) => c.trim().startsWith('__session='));
  } catch {
    return false;
  }
}
async function ensureSessionIfNeeded() {
  if (hasSessionCookie()) return;
  try {
    await fetch('/api/resolve-usercode', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: '{}',
    });
  } catch {}
}
async function authedFetch(input: RequestInfo, init: RequestInit = {}) {
  const headers = new Headers(init.headers || {});
  const token = await getIdTokenSafe(false);
  if (token) headers.set('Authorization', `Bearer ${token}`);
  else if (!hasSessionCookie()) await ensureSessionIfNeeded();

  const doFetch = () =>
    fetch(input, {
      ...init,
      headers,
      credentials: 'include',
      cache: 'no-store',
    });

  let res = await doFetch();
  if (res.status === 401 || res.status === 403) {
    await new Promise((r) => setTimeout(r, 200));
    const t2 = await getIdTokenSafe(true);
    const headers2 = new Headers(init.headers || {});
    if (t2) headers2.set('Authorization', `Bearer ${t2}`);
    res = await fetch(input, {
      ...init,
      headers: headers2,
      credentials: 'include',
      cache: 'no-store',
    });
  }
  return res;
}

// ---------------- client ----------------
const irosClient = {
  async listConversations(): Promise<IrosConversation[]> {
    const res = await authedFetch(`/api/agent/iros/conversations?__ts=${Date.now()}`, {
      method: 'GET',
    });
    if (!res.ok) throw new Error(`conversations failed: ${res.status}`);
    const data = await res.json().catch(() => ({}));
    const a = arr<any>(data);

    return a.map((it) => ({
      id: String(it.id),
      title: String(it.title ?? ''),
      created_at: it.created_at ?? it.createdAt ?? undefined,
      updated_at: it.updated_at ?? it.updatedAt ?? undefined,
    })) as IrosConversation[];
  },

  /** ← 追加：新規会話の発番（Authorization/Session 付きで安全に叩く） */
  async createConversation(): Promise<{ conversationId: string }> {
    const res = await authedFetch(`/api/agent/iros?__ts=${Date.now()}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      // サーバ側で新規発番。必要なら mode: 'init' 等に合わせてください
      body: JSON.stringify({}),
    });
    if (!res.ok) throw new Error(`create failed: ${res.status}`);
    const data = await res.json().catch(() => ({}));
    const cid = data.conversation_id || data.conversationId;
    if (!cid) throw new Error('create failed: no conversationId');
    return { conversationId: String(cid) };
  },

  async fetchMessages(conversationId: string): Promise<IrosMessage[]> {
    const res = await authedFetch(
      `/api/agent/iros/messages?conversation_id=${encodeURIComponent(conversationId)}&__ts=${Date.now()}`,
      { method: 'GET' },
    );
    if (!res.ok) throw new Error(`messages failed: ${res.status}`);
    const data = await res.json().catch(() => ({}));
    const rows = arr<any>(data);

    const mapped: WireMsg[] = rows.map((m: any) => {
      const ts = num(m.ts) ?? num(m.created_at) ?? num(m.createdAt) ?? Date.now();

      return {
        id: String(m.id ?? crypto.randomUUID()),
        role: m.role === 'user' ? 'user' : 'assistant',
        text: String(m.content ?? m.text ?? ''),
        q: m.q ?? m.q_code ?? undefined,
        color: m.color ?? undefined,
        ts,
      };
    });

    mapped.sort((a, b) => (a.ts ?? 0) - (b.ts ?? 0));
    // 最終地点だけ IrosMessage にまとめてキャスト（UI/Context の構造に合わせる）
    return mapped as unknown as IrosMessage[];
  },

  async sendText(input: SendIn): Promise<{ conversationId?: string; messages: IrosMessage[] }> {
    const res = await authedFetch(`/api/agent/iros?__ts=${Date.now()}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        conversationId: input.conversationId,
        text: input.text,
        mode: input.mode,
      }),
    });

    // POST 応答に rows が無い/遅い場合の即時フォールバック
    const now = Date.now();
    const draft: WireMsg[] = [
      { id: crypto.randomUUID(), role: 'user', text: input.text, ts: now },
      { id: crypto.randomUUID(), role: 'assistant', text: '…', ts: now + 1 },
    ];

    if (!res.ok) {
      return { conversationId: input.conversationId, messages: draft as unknown as IrosMessage[] };
    }

    const data = await res.json().catch(() => ({}));
    const cid = data.conversation_id || data.conversationId || input.conversationId;

    const rows = arr<any>(data);
    if (!rows.length) {
      return { conversationId: cid, messages: draft as unknown as IrosMessage[] };
    }

    const normalized: WireMsg[] = rows.map((m: any) => ({
      id: String(m.id ?? crypto.randomUUID()),
      role: m.role === 'user' ? 'user' : 'assistant',
      text: String(m.content ?? m.text ?? ''),
      q: m.q ?? m.q_code ?? undefined,
      color: m.color ?? undefined,
      ts: num(m.ts) ?? num(m.created_at) ?? num(m.createdAt) ?? Date.now(),
    }));

    normalized.sort((a, b) => (a.ts ?? 0) - (b.ts ?? 0));
    return { conversationId: cid, messages: normalized as unknown as IrosMessage[] };
  },

  async renameConversation(conversationId: string, title: string): Promise<void> {
    const res = await authedFetch(`/api/agent/iros/rename`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ conversation_id: conversationId, title }),
    });
    if (!res.ok) throw new Error(`rename failed: ${res.status}`);
  },

  async deleteConversation(conversationId: string): Promise<void> {
    const res = await authedFetch(`/api/agent/iros/delete`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ conversation_id: conversationId }),
    });
    if (!res.ok) throw new Error(`delete failed: ${res.status}`);
  },

  async getUserInfo(): Promise<any> {
    const res = await authedFetch(`/api/agent/iros/userinfo`, { method: 'GET' });
    if (!res.ok) throw new Error(`userinfo failed: ${res.status}`);
    return res.json().catch(() => ({}));
  },
};

export default irosClient;
