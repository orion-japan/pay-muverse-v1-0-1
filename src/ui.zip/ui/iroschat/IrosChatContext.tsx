'use client';

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { useAuth } from '@/context/AuthContext';
import irosClient from './lib/irosClient';
import type { IrosConversation, IrosMessage } from './types';

type Ctx = {
  loading: boolean;
  error?: string;
  conversations: IrosConversation[];
  conversationId?: string;
  messages: IrosMessage[];
  selectConversation: (id: string) => Promise<void>;
  send: (text: string) => Promise<void>;
  rename: (title: string) => Promise<void>;
  remove: () => Promise<void>;
  refreshMessages: () => Promise<void>;
};

const IrosCtx = createContext<Ctx | null>(null);
export function useIrosChat(): Ctx {
  const c = useContext(IrosCtx);
  if (!c) throw new Error('IrosChatContext not mounted');
  return c;
}

function IrosChatProvider({
  children,
  initialConversationId,
}: {
  children: React.ReactNode;
  /** URL などから渡される既存の会話ID（任意） */
  initialConversationId?: string;
}) {
  const { userCode, loading: authLoading } = useAuth();
  const canUse = !!userCode && !authLoading;

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>();
  const [conversations, setConversations] = useState<IrosConversation[]>([]);
  const [conversationId, setConversationId] = useState<string | undefined>(initialConversationId);
  const [messages, setMessages] = useState<IrosMessage[]>([]);
  const fetchLock = useRef<boolean>(false);
  const didInit = useRef(false);

  // ---- 共通：401/403 を待って指数バックオフで再試行 ----
  async function retryAuth<T>(
    fn: () => Promise<T>,
    opt: { tries?: number; baseMs?: number } = {},
  ): Promise<T> {
    const tries = opt.tries ?? 6;
    const baseMs = opt.baseMs ?? 500;
    let lastErr: any;
    for (let i = 0; i < tries; i++) {
      try {
        return await fn();
      } catch (e: any) {
        lastErr = e;
        const msg = String(e?.message ?? e);
        const isAuth = /\b(401|403)\b/.test(msg);
        if (!isAuth && i >= 1) break;
        await new Promise((r) => setTimeout(r, baseMs * Math.pow(1.8, i)));
      }
    }
    throw lastErr;
  }

  // --- 会話IDを必ず確定させる（未確定なら API で発番） ---
  const ensureConversationId = useCallback(async (): Promise<string> => {
    if (conversationId) return conversationId;

    const cid = await retryAuth(async () => {
      const created = await irosClient.createConversation(); // ← 認証ヘッダ付き
      const got: string | undefined = created?.conversationId;
      if (!got) throw new Error('Failed to ensure conversation id');
      return got;
    });

    setConversationId(cid);
    return cid;
  }, [conversationId]);

  // 初期ロード：会話一覧＋初期cidの反映（Auth準備後に一度だけ）
  useEffect(() => {
    if (!canUse) return;
    if (didInit.current) return;
    didInit.current = true;

    (async () => {
      try {
        setLoading(true);

        // 1) 会話一覧（401なら待つ）
        const list = await retryAuth(() => irosClient.listConversations());
        setConversations(list);

        // 2) 初期cid決定：props → 既存state → 一覧先頭 →（なければ発番）
        let cid =
          initialConversationId ||
          conversationId ||
          (list.length > 0 ? list[0].id : undefined);

        if (!cid) cid = await ensureConversationId();
        else setConversationId(cid);

        // 3) 初期メッセージ取得（401なら待つ）
        const msgs = await retryAuth(() => irosClient.fetchMessages(cid));
        setMessages(msgs);
      } catch (e: any) {
        setError(e?.message ?? String(e));
        setMessages([]);
      } finally {
        setLoading(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canUse]);

  // initialConversationId の後追い変更にも追随
  useEffect(() => {
    if (initialConversationId && !conversationId) {
      setConversationId(initialConversationId);
    }
  }, [initialConversationId, conversationId]);

  const refreshMessages = useCallback(async () => {
    if (fetchLock.current) return;
    fetchLock.current = true;
    try {
      const cid = await ensureConversationId();
      const list = await retryAuth(() => irosClient.fetchMessages(cid));
      setMessages(list);
    } catch (e: any) {
      setError(e?.message ?? String(e));
    } finally {
      fetchLock.current = false;
    }
  }, [ensureConversationId]);

  const selectConversation = useCallback(async (id: string) => {
    setConversationId(id);
    setError(undefined);
    setLoading(true);
    try {
      const list = await retryAuth(() => irosClient.fetchMessages(id));
      setMessages(list);
    } catch (e: any) {
      setError(e?.message ?? String(e));
      setMessages([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const send = useCallback(
    async (text: string) => {
      setError(undefined);
      setLoading(true);
      try {
        const baseCid = await ensureConversationId();

        const { conversationId: cid, messages: draft } = await retryAuth(() =>
          irosClient.sendText({ conversationId: baseCid, text }),
        );

        if (!conversationId && cid) setConversationId(cid);
        setMessages(draft);

        await retry(async () => {
          const target = cid || conversationId || baseCid;
          const list = await irosClient.fetchMessages(target);
          setMessages(list);
        }, { tries: 3, baseMs: 250 });
      } catch (e: any) {
        setError(e?.message ?? String(e));
      } finally {
        setLoading(false);
      }
    },
    [conversationId, ensureConversationId],
  );

  const rename = useCallback(
    async (title: string) => {
      if (!conversationId) return;
      setError(undefined);
      try {
        await retryAuth(() => irosClient.renameConversation(conversationId, title));
        setConversations(prev =>
          prev.map(c => (c.id === conversationId ? { ...c, title } : c)),
        );
      } catch (e: any) {
        setError(e?.message ?? String(e));
      }
    },
    [conversationId],
  );

  const remove = useCallback(async () => {
    if (!conversationId) return;
    setError(undefined);
    try {
      await retryAuth(() => irosClient.deleteConversation(conversationId));
      setConversations(prev => prev.filter(c => c.id !== conversationId));
      setConversationId(undefined);
      setMessages([]);
    } catch (e: any) {
      setError(e?.message ?? String(e));
    }
  }, [conversationId]);

  const value = useMemo<Ctx>(
    () => ({
      loading,
      error,
      conversations,
      conversationId,
      messages,
      selectConversation,
      send,
      rename,
      remove,
      refreshMessages,
    }),
    [
      loading,
      error,
      conversations,
      conversationId,
      messages,
      selectConversation,
      send,
      rename,
      remove,
      refreshMessages,
    ],
  );

  return <IrosCtx.Provider value={value}>{children}</IrosCtx.Provider>;
}

// 通常リトライ（非認証系）
async function retry<T>(fn: () => Promise<T>, opt: { tries: number; baseMs: number }) {
  let lastErr: any;
  for (let i = 0; i < opt.tries; i++) {
    try {
      return await fn();
    } catch (e) {
      lastErr = e;
      await new Promise(r => setTimeout(r, opt.baseMs * Math.pow(2, i)));
    }
  }
  throw lastErr;
}

export { IrosChatProvider };
export default IrosChatProvider;
